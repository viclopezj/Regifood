package cl.duoc.empleados_service.dto;

import lombok.Data;
import java.util.List;

@Data
public class EmpleadoDTO {
    private Long id;
    private String nombreCompleto;
    private LocalDTO local;
}
