INSERT INTO empleados (nombre, apellido, email, fono, salario, id_local) VALUES
     ('Juan', 'Gómez', 'jgomez@mail.com', '+56900011122', 550000, 1),
     ('María', 'Torres', 'mtorres@mail.com', '+56933344455', 600000, 1),
     ('Pedro', 'Salas', 'psalas@mail.com', '+56966677788', 580000, 2),
     ('Lucía', 'Ramos', 'lramos@mail.com', '+56999988877', 620000, 3);