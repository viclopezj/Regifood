package cl.duoc.ventas_service.repository;

import cl.duoc.ventas_service.model.Venta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VentaRepository extends JpaRepository<Venta, Long> {

    List<Venta> findAllByLocal(Long local);
    List<Venta> findAllByVentaMaximasLessThanEqual(Integer ventaMaximasIsLessThan);
    List<Venta> findAllByVentaMinimasGreaterThanEqual(Integer ventaMinimasIsGreaterThan);
    List<Venta> findAllByVentaPromedioGreaterThanEqual(Integer ventaPromedioIsGreaterThan);
}
