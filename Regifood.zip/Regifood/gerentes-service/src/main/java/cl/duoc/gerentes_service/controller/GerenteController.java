package cl.duoc.gerentes_service.controller;

import cl.duoc.gerentes_service.dto.GerenteDTO;
import cl.duoc.gerentes_service.model.Gerente;
import cl.duoc.gerentes_service.service.GerenteService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/gerentes")
public class GerenteController {

    @Autowired
    private GerenteService gerenteService;

    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(gerenteService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        Gerente gerente = gerenteService.findById(id);
        if (gerente == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(gerente);
    }

    @PostMapping
    public ResponseEntity<?> registrar(@Valid @RequestBody Gerente gerente) {
        Gerente gerenteNuevo = gerenteService.save(gerente);
        return new ResponseEntity<>(gerenteNuevo, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(@PathVariable Long id, @Valid @RequestBody Gerente gerente) {
        Gerente gerenteActualizado = gerenteService.update(id, gerente);
        if (gerenteActualizado == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(gerenteActualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id) {
        gerenteService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/listado")
    public ResponseEntity<?> listarDTO(){
        return ResponseEntity.ok(gerenteService.findDTOList());
    }

    @GetMapping("/listado/{id}")
    public ResponseEntity<?> buscarPorIdDTO(@PathVariable Long id){
        GerenteDTO gerente = gerenteService.findDTO(id);
        if (gerente == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(gerente);
    }

    @GetMapping("/email/{email}")
    public ResponseEntity<?> gerentePorEmail( @PathVariable String email){
        return ResponseEntity.ok(gerenteService.findByEmail(email));
    }

    @GetMapping("/salario-mayor/{salario}")
    public ResponseEntity<?> gerentePorSalarioMayor( @PathVariable Integer salario){
        return ResponseEntity.ok(gerenteService.findBySalarioGreaterEqual(salario));
    }

    @GetMapping("/salario-menor/{salario}")
    public ResponseEntity<?> gerentePorSalarioMenor( @PathVariable Integer salario){
        return ResponseEntity.ok(gerenteService.findBySalarioLessEqual(salario));
    }

    @GetMapping("/bono-mayor/{bono}")
    public ResponseEntity<?> gerentePorBonoMayor( @PathVariable Integer bono){
        return ResponseEntity.ok(gerenteService.findByBonoGreaterEqual(bono));
    }

    @GetMapping("/bono-menor/{bono}")
    public ResponseEntity<?> gerentePorBonoMenor( @PathVariable Integer bono){
        return ResponseEntity.ok(gerenteService.findByBonoLessEqual(bono));
    }
}
