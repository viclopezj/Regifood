package cl.duoc.gerentes_service.dto;

import lombok.Data;

@Data
public class GerenteDTO {
    private Long id;
    private String nombreCompleto;
    private String nivelMando;
}
