package cl.duoc.gerentes_service.service;

import cl.duoc.gerentes_service.dto.GerenteDTO;
import cl.duoc.gerentes_service.mapper.GerenteMapper;
import cl.duoc.gerentes_service.model.Gerente;
import cl.duoc.gerentes_service.repository.GerenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class GerenteService {

    @Autowired
    private GerenteRepository gerenteRepository;
    @Autowired
    private GerenteMapper gerenteMapper;

    public List<Gerente> findAll() {
        return gerenteRepository.findAll();
    }
    public Gerente findById(Long id){
        return gerenteRepository.findById(id).orElse(null);
    }
    public Gerente save(Gerente gerente) {
        return gerenteRepository.save(gerente);
    }
    public Gerente update(Long id, Gerente gerente) {
        Gerente gerenteActualizar = gerenteRepository.findById(id).orElse(null);
        if (gerenteActualizar == null) return null;
        // Mapear campos aquí
        gerenteActualizar.setNombre(gerente.getNombre());
        gerenteActualizar.setApellido(gerente.getApellido());
        gerenteActualizar.setEmail(gerente.getEmail());
        gerenteActualizar.setFono(gerente.getFono());
        gerenteActualizar.setSalario(gerente.getSalario());
        gerenteActualizar.setBono(gerente.getBono());
        gerenteActualizar.setNivelMando(gerente.getNivelMando());
        return gerenteRepository.save(gerente);
    }
    public void delete(Long id) {
        gerenteRepository.deleteById(id);
    }

    public GerenteDTO findDTO(Long id){
        return gerenteMapper.toDTO(findById(id));
    }

    public List<GerenteDTO> findDTOList() {
        return gerenteMapper.toDTOlist(findAll());
    }

}

