INSERT INTO gerentes (nombre, apellido, email, fono, salario, bono, nivel_mando) VALUES
    ('Carlos', 'Pérez', 'cperez@gmail.com', '+56912345678', 1500000, 200000, 'Senior'),
    ('Ana', 'López', 'alopez@outlook.com', '+56987654321', 1200000, 150000, 'Junior'),
    ('Roberto', 'Soto', 'rsoto@empresa.cl', '+56955566677', 1800000, 300000, 'Regional');