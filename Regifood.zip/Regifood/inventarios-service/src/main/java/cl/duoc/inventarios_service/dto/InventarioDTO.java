package cl.duoc.inventarios_service.dto;

import lombok.Data;

@Data
public class InventarioDTO {
    private Long id;
    private String nombre;
    private Integer cantidadActual;
    private LocalDTO local;
    private ProveedorDTO proveedor;
}
