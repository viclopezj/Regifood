INSERT INTO inventarios (nombre_insumo, cantidad_actual, id_local, id_proveedor)VALUES
    ('Harina de Trigo', 50, 1, 1),
    ('Detergente Industrial', 20, 2, 5),
    ('Carne de Vacuno kg', 100, 5, 5),
    ('Cajas de Pizza', 200, 2, 1);