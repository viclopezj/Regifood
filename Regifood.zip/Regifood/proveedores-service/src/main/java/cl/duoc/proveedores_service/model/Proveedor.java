package cl.duoc.proveedores_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "proveedores")
public class Proveedor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "Nombre no puede estar vacio.")
    private String nombreEmpresa;
    @NotBlank(message = "Email no puede estar vacio.")
    private String email;
    @NotBlank(message = "Fono no puede estar vacio.")
    private String fono;
    @NotBlank(message = "Tipo de Proveedor no puede estar vacio.")
    private String tipoProveedor;
}
