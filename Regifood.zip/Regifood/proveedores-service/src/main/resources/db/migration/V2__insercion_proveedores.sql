INSERT INTO proveedores (nombre_empresa, email, fono, tipo_proveedor) VALUES
     ('Distribuidora Alimentos S.A.', 'contacto@alimentos.cl', '+56911112222', 'Alimentos'),
     ('Muebles y Equipos Spa', 'ventas@muebles.net', '+56223334444', 'Infraestructura'),
     ('Insumos Pro Chile', 'info@insumospro.cl', '+56955556666', 'Limpieza'),
     ('Tecnología Gastronómica', 'soporte@tecno.com', '+56228889999', 'Maquinaria'),
     ('Carnes Premium Ltda', 'ventas@carnes.cl', '+56977778888', 'Alimentos');