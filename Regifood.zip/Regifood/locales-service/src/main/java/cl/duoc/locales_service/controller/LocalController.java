package cl.duoc.locales_service.controller;

import cl.duoc.locales_service.dto.LocalDTO;
import cl.duoc.locales_service.model.Local;
import cl.duoc.locales_service.service.LocalService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/locales")
public class LocalController {
    @Autowired
    private LocalService localService;

    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(localService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        Local local = localService.findById(id);
        if (local == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(local);
    }

    @PostMapping
    public ResponseEntity<?> registrar(@Valid @RequestBody Local local) {
        Local localNueva = localService.save(local);
        return new ResponseEntity<>(localNueva, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(@PathVariable Long id, @Valid @RequestBody Local local) {
        Local localActualizado = localService.update(id, local);
        if (localActualizado == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(localActualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id) {
        localService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/listado")
    public ResponseEntity<?> listarDTO(){
        return ResponseEntity.ok(localService.findDTOList());
    }
    @GetMapping("/listado/{id}")
    public ResponseEntity<?> buscarPorIdDTO(@PathVariable Long id) {
        LocalDTO local = localService.findDTO(id);
        if (local == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(local);
    }

    @GetMapping("/comuna/{comuna}")
    public ResponseEntity<?> localPorComuna( @PathVariable String comuna){
        return ResponseEntity.ok(localService.findByComuna(comuna));
    }

    @GetMapping("/gerente-id/{id}")
    public ResponseEntity<?> localPorGerenteId( @PathVariable Long id){
        return ResponseEntity.ok(localService.findByIdGerente(id));
    }

    @GetMapping("/gerente-tipo/{gerente}")
    public ResponseEntity<?> localPorGerenteTipo( @PathVariable String gerente){
        return ResponseEntity.ok(localService.findByTipoGerente(gerente));
    }
}
