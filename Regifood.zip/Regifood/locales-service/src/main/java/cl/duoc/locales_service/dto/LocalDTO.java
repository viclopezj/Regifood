package cl.duoc.locales_service.dto;

import lombok.Data;

@Data
public class LocalDTO {
    private Long id;
    private String nombre;
    private String horasHabiles;
    private GerenteDTO gerente;
}
