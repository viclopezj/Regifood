package cl.duoc.locales_service.dto;

import lombok.Data;

@Data
public class GerenteDTO {
    private Long id;
    private String nombreCompleto;
    private String nivelMando;
}
