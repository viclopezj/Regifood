package cl.duoc.locales_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableDiscoveryClient
@EnableFeignClients
@SpringBootApplication
public class LocalesServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocalesServiceApplication.class, args);
	}

}
