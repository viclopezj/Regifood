INSERT INTO locales (nombre, comuna, direccion, hora_apertura, hora_cierre, id_gerente) VALUES
    ('Bistro Duoc UC', 'Puente Alto', 'Av. Concha y Toro 1340', '08:00:00', '22:00:00',1),
    ('La Picá de Maipú', 'Maipú', 'Av. Pajaritos 450', '09:00:00', '23:00:00',2),
    ('Sabores de Providencia', 'Providencia', 'Av. Lyon 120', '10:00:00', '23:30:00',3),
    ('Express Santiago', 'Santiago', 'Huérfanos 1020', '07:30:00', '20:00:00',3),
    ('Costa Central', 'Viña del Mar', 'Calle Valparaíso 550', '11:00:00', '01:00:00', 3);