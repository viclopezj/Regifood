-- 1. INSERCIÓN DE MARCAS
-- Catálogo de marcas especializadas en el rubro gastronómico
INSERT INTO marcas (codigo, nombre) VALUES ('RAT-01', 'Rational');        -- Maquinaria pesada
INSERT INTO marcas (codigo, nombre) VALUES ('WIN-02', 'Winterhalter');   -- Lavado/Limpieza industrial
INSERT INTO marcas (codigo, nombre) VALUES ('TRA-03', 'Tramontina');     -- Mobiliario y acero
INSERT INTO marcas (codigo, nombre) VALUES ('MAQ-04', 'Maquipan');       -- Panadería y equipos
INSERT INTO marcas (codigo, nombre) VALUES ('UNX-05', 'Unox');           -- Hornos y cocción

-- 2. INSERCIÓN DE EQUIPOS

INSERT INTO equipos (nombre, cod_marca, fecha_compra, ultima_mantencion, proxima_mantencion, id_proveedor) VALUES
 -- Equipo suministrado por 'Tecnología Gastronómica' (ID 4 - Maquinaria)
('Horno Combinado iCombi Pro', 'RAT-01', '2025-01-15', '2026-03-10', '2026-09-10', 4),
-- Equipo suministrado por 'Insumos Pro Chile' (ID 3 - Limpieza)
('Lavavajillas de Capota PT-M', 'WIN-02', '2024-11-20', '2026-05-01', '2026-11-01', 3),
-- Equipo suministrado por 'Muebles y Equipos Spa' (ID 2 - Infraestructura)
('Mesón Refrigerado 3 Puertas', 'TRA-03', '2026-02-01', '2026-02-01', '2027-02-01', 2),
-- Equipo suministrado por 'Tecnología Gastronómica' (ID 4 - Maquinaria)
('Amasadora Espiral 25kg', 'MAQ-04', '2025-06-15', '2026-01-20', '2026-07-20', 4),
-- Otro equipo de infraestructura (ID 2)
('Estantería Acero Quirúrgico', 'TRA-03', '2026-03-20', '2026-03-20', '2028-03-20', 2);