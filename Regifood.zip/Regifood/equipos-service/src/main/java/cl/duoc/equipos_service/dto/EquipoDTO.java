package cl.duoc.equipos_service.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class EquipoDTO {
    private Long id;
    private String nombre;
    private String marca;
    private ProveedorDTO proveedor;
}
