-- 1. INSERCIÓN DE CATEGORÍAS
INSERT INTO categorias (codigo, nombre)
VALUES ('ALM', 'Almuerzos');
INSERT INTO categorias (codigo, nombre)
VALUES ('CEN', 'Cenas');
INSERT INTO categorias (codigo, nombre)
VALUES ('CAF', 'Cafetería');
INSERT INTO categorias (codigo, nombre)
VALUES ('SAL', 'Saludable');
INSERT INTO categorias (codigo, nombre)
VALUES ('ENT', 'Entradas');
INSERT INTO categorias (codigo, nombre)
VALUES ('BEB', 'Bebestibles');

-- 2. INSERCIÓN DE MENÚS
INSERT INTO menus (nombre, precio, cod_categoria, id_local)
VALUES
-- Menús para Bistro Duoc UC (ID 1)
('Menú Ejecutivo Duoc', 5500, 'ALM', 1),
('Promo Desayuno Estudiante', 2990, 'CAF', 1),
-- Menús para La Picá de Maipú (ID 2)
('Parrillada Familiar', 25000, 'CEN', 2),  -- Usando 'CEN' si decides normalizar o 'Cenas' si prefieres el texto
('Cazuela de Vacuno', 6500, 'ALM', 2),
-- Menús para Sabores de Providencia (ID 3)
('Café Latte de Especialidad', 3800, 'CAF', 3),
('Cheesecake de Arándanos', 4200, 'ENT', 3), -- Categorizado como entrada/postre
-- Menús para Express Santiago (ID 4)
('Sandwich de Mechada', 7500, 'ALM', 4),
('Jugo Natural del Día', 2500, 'BEB', 4),
-- Menús para Costa Central (ID 5)
('Reineta a la Plancha', 11900, 'ALM', 5),
('Paila Marina Especial', 14500, 'CEN', 5);