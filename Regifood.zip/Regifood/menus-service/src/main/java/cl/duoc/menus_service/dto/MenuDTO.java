package cl.duoc.menus_service.dto;

import lombok.Data;

@Data
public class MenuDTO {
    private Long id;
    private String nombre;
    private String categoria;
    private LocalDTO local;
}
