package cl.duoc.menus_service.service;

import cl.duoc.menus_service.model.Categoria;
import cl.duoc.menus_service.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepository;

    public List<Categoria> findAll(){
        return categoriaRepository.findAll();
    }
    public Categoria findById(String codigo){
        return categoriaRepository.findByCodigoIgnoreCase(codigo);
    }
    public Categoria save(Categoria categoria){
        return categoriaRepository.save(categoria);
    }
    public Categoria update(String codigo, Categoria categoria){
        Categoria categoriaActualizar = categoriaRepository.findById(codigo).orElse(null);
        if (categoriaActualizar == null) return null;
        categoria.setNombre(categoria.getNombre());
        return categoriaRepository.save(categoria);
    }
    public void delete(String codigo){
        categoriaRepository.deleteById(codigo);
    }
}
